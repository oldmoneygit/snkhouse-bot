=== SNKHOUSE Chat ===
Contributors: SNKHOUSE
Tags: chat, widget, ai
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.2
Requires PHP: 7.4
License: GPLv2 or later

Chat widget con IA para atención al cliente

== Description ==

SNKHOUSE Chat es un sistema de chat con inteligencia artificial.

== Installation ==

1. Sube el plugin via WordPress Admin
2. Activa el plugin
3. Configura en Configuración -> SNKHOUSE Chat

== Changelog ==

= 1.0.2 =
* Versión inicial simplificada
